/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   CSSFunctions.h
 * Author: V Shemetov
 *
 * Created on June 2, 2017, 12:04 PM
 */

#pragma once

#include <cmath>
#include <time.h>
#include <QDebug>



namespace css {
namespace functions {

// Многооборотный потенциометр
class MultiTurnPotentiometer {
public:
    MultiTurnPotentiometer();
    MultiTurnPotentiometer(float r_thold);

    float countSemval(float current_angle);
    void  setA0(float start_angle);
    void  setCurrentSemval(float semval);
    void  setRange(float range_left, float range_rite);
    void  setCoeffs(float resolution, float semval_step);
    void  setThreshold(float r_thold);

protected:
    float a0;
    float dSemval;
    float range_left;
    float range_rite;
    float current_semval;
    float resolution;
    float semval_step;
    float reset_threshold_a0;

private:
    void init();
};

// Класс функций
class CSSFunctions {
public:
    
    static inline float rad2deg(float rad_value) {
        return (rad_value * (180.f / M_PI));
    }

    static inline float deg2rad(float deg_value) {
        return (deg_value * (M_PI / 180.f));
    }

    static inline float inch2m(float inch_value) {
        return (inch_value * 0.0254);
    }

    static inline float m2inch(float m_value) {
        return (m_value * 39.3701);
    }

    static float kts2kmhs(float kts_value);
    static float ft2m(float ft_value);
    static float m2ft(float m_value);

    static inline float m2km(float m_value) {
        return (m_value * 0.001);
    }

    static float mapI2F(int in_value,
            float in_min,
            float in_max,
            float out_min,
            float out_max);

    static float mapF2F(float in_value,
                        float in_min,
                        float in_max,
                        float out_min,
                        float out_max);

    template<typename T>
    static void saturate(T &value, T min, T max) {
        if (value > max)
            value = max;

        if (value < min)
            value = min;
    }

    static int  byteArrayToInt(char b[]);
    static void binarySwitch(unsigned short &value);
    static void incDecOnRange(unsigned short &value, int min, int max, bool &direction);
    static bool isOnRange(double value, double gauge, float accuracy);

    template<typename T>
    static void incLim(T &value, T max, T d) {
        if (value < max)
            value += d;
    }

    template<typename T>
    static void decLim(T &value, T min, T d) {
        if (value > min)
            value -= d;
    }


    static inline float freqDeg2Semval(float dDeg, float resolution, float semval_step) {
        return (roundf(dDeg / resolution) * semval_step);
    }
};

}
}

