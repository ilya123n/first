#pragma once

#include <QtCore>

namespace css {

// данные пришедшие от ВСУП

struct AllData{

    float ind_speed;                    // индикатор задатчика прборной скорости
    float ind_altitude;                 // индикатор задатчика высоты эшелона
    float ind_vertical_speed;           // индикатор задатчика вертикальной скорости
    float ind_angle;                    // индикатор задатчика ЗПУ

    float yoke_roll;                    // отклонене штурвала по крену
    float yoke_pitch;                   // отклонене штурвала по тангажу

    float pedal_left;                   // отклонения педалей левого пилота
    float pedal_left_left;              // нажатие левой педали левого пилота
    float pedal_left_right;             // нажатие правой педали левого пилота

    float pedal_right;                  // отклонения педалей правого пилота
    float pedal_right_left;             // нажатие левой педали правого пилота
    float pedal_right_right;            // нажатие правой педали правого пилота

    float CST_1;                        // отклонение РУД_1
    float CST_2;                        // отклонение РУД_2
    float CST_3;                        // отклонение РУД_3
    float CST_4;                        // отклонение РУД_4

    float REV_1;                        // ВКЛ РЕВЕРСА_1
    float REV_2;                        // ВКЛ РЕВЕРСА_2
    float REV_3;                        // ВКЛ РЕВЕРСА_3
    float REV_4;                        // ВКЛ РЕВЕРСА_4

    float inc_speed;                    // приращение значения на индикаторе задатчика скорости
    float inc_altitude;                 // приращение значения на индикаторе задатчика эшелона
    float inc_vertspeed;                // приращение значения на индикаторе задатчика вертикальной скорости
    float inc_angle;                    // приращение значения на индикаторе задатчика путевого угла

    int control_flat;                  // ручка управления закрылками
    float control_spoiler;               // ручка управления интерцепторами

    char dircontrol_left;               // выключатель директорного управления левого пилота
    char button_stab2;                  // кнопка включения-выключения режима «Стабилизация N2»
    char button_at;                     // кнопка подготовки ВСУТ к автоматическому управлению тягой двигателя
    char button_at_off;                 // кнопка выключения автоматического управления тягой двигателя
    char button_speed;                  // кнопка включения режима «Скорость»
    char button_echelon;                // кнопка включения режима «Выход на заданный эшелон»
    char button_stab_altitude;          // кнопка включения режима «Стабилизация высоты»
    char button_navig_vert;             // кнопка включения режима «Вертикальная навигация»
    char button_beam;                   // кнопка включения режима «Обратный луч»
    char button_vertspeed;              // кнопка включения режима «Вертикальная скорость»
    char button_land;                   // кнопка включения режима «Посадка»
    char button_zpu;                    // кнопка включения режима «ЗПУ»
    char button_zona;                   // кнопка включения режима «Курсовая зона»
    char button_navig_gor;              // кнопка включения режима «Горизонтальная навигация»
    char button_ON;                     // кнопка включения автоматического управления самолетом (режим «совмещенное управление»)
    char button_OFF;                    // кнопка выключения автоматического управления самолетом
    char dircontrol_right;              // выключатель директорного управления правого пилота
    char button_mach;                   // режим отображения скорости (М или км/ч), переключаемый кнопкой V/M

    char waveoff_left;                  // уход на второй круг (левая кнопка)
    char waveoff_right;                 // уход на второй круг (правая кнопка)
    char off_at_left;                   // отключение автомата тяги (левая кнопка)
    char off_at_right;                  // отключение автомата тяги (правая кнопка)

    int yoke_stab_trim_left_1;         // трим стабилизатора 1 (левый штурвал)
    //char yoke_stab_trim_left_2;         // трим стабилизатора 2 (левый штурвал)
    int  off_vsup_left;                 // отключение ВСУП (левый штурвал)

    int yoke_stab_trim_right_1;        // трим стабилизатора 1 (правый штурвал)
    //char yoke_stab_trim_right_2;        // трим стабилизатора 2 (правый штурвал)
    char off_vsup_right;                // отключение ВСУП (правый штурвал)


    AllData() {

        ind_speed = 0.0;                 // индикатор задатчика прборной скорости
        ind_altitude = 0.0;              // индикатор задатчика высоты эшелона
        ind_vertical_speed = 0.0;        // индикатор задатчика вертикальной скорости
        ind_angle = 0.0;                 // индикатор задатчика ЗПУ

        yoke_roll = 0.0;
        yoke_pitch = 0.0;

        pedal_left = 0.0;                 // отклонения педалей левого пилота
        pedal_left_left = 0.0;            // нажатие левой педали левого пилота
        pedal_left_right = 0.0;           // нажатие правой педали левого пилота

        pedal_right = 0.0;                // отклонения педалей правого пилота
        pedal_right_left = 0.0;           // нажатие левой педали правого пилота
        pedal_right_right = 0.0;          // нажатие правой педали правого пилота

        CST_1 = 0.0;
        CST_2 = 0.0;
        CST_3 = 0.0;error: undefined reference to `String::String(char const*)'
        CST_4 = 0.0;

        REV_1 = 0.0;                      // ВКЛ РЕВЕРСА_1
        REV_2 = 0.0;                      // ВКЛ РЕВЕРСА_2
        REV_3 = 0.0;                      // ВКЛ РЕВЕРСА_3
        REV_4 = 0.0;                      // ВКЛ РЕВЕРСА_4

        inc_speed = 0.0;                  // приращение значения на индикаторе задатчика скорости
        inc_altitude = 0.0;               // приращение значения на индикаторе задатчика эшелона
        inc_vertspeed = 0.0;              // приращение значения на индикаторе задатчика вертикальной скорости
        inc_angle = 0.0;                  // приращение значения на индикаторе задатчика путевого угла

        control_flat = 0;              // ручка управления закрылками
        control_spoiler = 0.0;           // ручка управления интерцепторами

        //control_flat = 0x00;              // ручка управления закрылками
        //control_spoiler = 0x00;           // ручка управления интерцепторами

        dircontrol_left = 0x00;           // выключатель директорного управления левого пилота
        button_stab2 = 0x00;              // кнопка включения-выключения режима «Стабилизация N2»
        button_at = 0x00;                 // кнопка подготовки ВСУТ к автоматическому управлению тягой двигателя
        button_at_off = 0x00;             // кнопка выключения автоматического управления тягой двигателя
        button_speed = 0x00;              // кнопка включения режима «Скорость»
        button_echelon = 0x00;            // кнопка включения режима «Выход на заданный эшелон»
        button_stab_altitude = 0x00;      // кнопка включения режима «Стабилизация высоты»
        button_navig_vert = 0x00;         // кнопка включения режима «Вертикальная навигация»
        button_vertspeed = 0x00;          // кнопка включения режима «Вертикальная скорость»
        button_beam = 0x00;               // кнопка включения режима «Обратный луч»
        button_land = 0x00;               // кнопка включения режима «Посадка»
        button_zpu = 0x00;                // кнопка включения режима «ЗПУ»
        button_zona = 0x00;               // кнопка включения режима «Курсовая зона»
        button_navig_gor = 0x00;          // кнопка включения режима «Горизонтальная навигация»
        button_ON = 0xFF;                 // кнопка включения автоматического управления самолетом (режим «совмещенное управление»)
        button_OFF = 0x00;                // кнопка выключения автоматического управления самолетом
        dircontrol_right = 0x00;          // выключатель директорного управления правого пилота
        button_mach = 0x00;               // режим отображения скорости (М или км/ч), переключаемый кнопкой V/M


        off_vsup_left = 0;

        /*
        waveoff_left;                     // уход на второй круг (левая кнопка)
        waveoff_right;                    // уход на второй круг (правая кнопка)
        off_at_left;                      // отключение автомата тяги (левая кнопка)
        off_at_right;                     // отключение автомата тяги (правая кнопка)

        yoke_stab_trim_left_1;            // трим стабилизатора 1 (левый штурвал)
        yoke_stab_trim_left_2;            // трим стабилизатора 2 (левый штурвал)
        off_vsup_left;                    // отключение ВСУП (левый штурвал)

        yoke_stab_trim_right_1;           // трим стабилизатора 1 (правый штурвал)
        yoke_stab_trim_right_2;           // трим стабилизатора 2 (правый штурвал)
        off_vsup_right;                   // отключение ВСУП (правый штурвал)
        */

    }

    //метод для введения ограничения значений индицируемых на панели ВСУП
    void limit(float edit_speed, float edit_altitude, float edit_vertical_speed, float edit_angle, float kspeed, float kaltitude, float kvertspeed, float kangle) {

        if((ind_speed + edit_speed * kspeed) >=  600.0){
            ind_speed = 600.0;
        }else if((ind_speed + edit_speed * kspeed) <= 0.0){
            ind_speed = 0.0;
        }else ind_speed = ind_speed + edit_speed * kspeed;


        if((ind_altitude + edit_altitude * kaltitude) >=  13100.0){
            ind_altitude = 13100.0;
        }else if((ind_altitude + edit_altitude * kaltitude) <= 0.0){
            ind_altitude = 0.0;
        }else ind_altitude = ind_altitude + edit_altitude * kaltitude;


        if((ind_vertical_speed + edit_vertical_speed * kvertspeed) >=  30.0){
            ind_vertical_speed = 30.0;
        }else if((ind_vertical_speed + edit_vertical_speed * kvertspeed) <= -30.0){
            ind_vertical_speed = -30.0;
        }else ind_vertical_speed = ind_vertical_speed + edit_vertical_speed * kvertspeed;



        if((ind_angle + edit_angle * kangle) >=  360.0){
            ind_angle = 360.0;


        }else if((ind_angle + edit_angle * kangle) <= 0.0){
            ind_angle = 0.0;

        }else {ind_angle = ind_angle + edit_angle * kangle;

}


       // qDebug() << "ЗПУ" << ind_angle;
    }

    QString send_control(){

        QString message;

        message = QString::number(yoke_roll) + ',' + QString::number(yoke_pitch) + ',' + QString::number(pedal_left) + ',' + QString::number(pedal_left_left)+ ','
                + QString::number(pedal_left_right) +',' + QString::number(pedal_right) + ',' + QString::number(pedal_right_left) + ',' + QString::number(pedal_right_right) + ','
                + QString::number(CST_1) + ','+ QString::number(CST_2) + ',' + QString::number(CST_3) + ',' + QString::number(CST_4) + ',' + QString::number(control_flat) + ','
                + QString::number(control_spoiler) + ',' + QString::number(REV_1) + ','+ QString::number(REV_2) + ',' + QString::number(REV_3) + ',' + QString::number(REV_4);

      //  qDebug () << "CONTROL " << message;

        return message;
    }

    QString send_ap(){

        QString message;

        message = QString::number(ind_speed) + ',' + QString::number(ind_altitude) + ',' + QString::number(ind_vertical_speed) + ',' + QString::number(ind_angle)+ ','
                + QString::number((float)(quint8)dircontrol_left) + ',' + QString::number((float)(quint8)button_stab2) + ',' + QString::number((float)(quint8)button_at) + ','
                + QString::number((float)(quint8)button_at_off) + ',' + QString::number((float)(quint8)button_speed) + ',' + QString::number((float)(quint8)button_echelon) + ','
                + QString::number((float)(quint8)button_stab_altitude) + ',' + QString::number((float)(quint8)button_navig_vert) + ',' + QString::number((float)(quint8)button_vertspeed) + ','
                + QString::number((float)(quint8)button_beam) + ',' + QString::number((float)(quint8)button_land) + ',' + QString::number((float)(quint8)button_zpu) + ','
                + QString::number((float)(quint8)button_zona) + ',' + QString::number((float)(quint8)button_navig_gor) + ',' + QString::number((float)(quint8)button_ON) + ','
                + QString::number((float)(quint8)button_OFF) + ',' + QString::number((float)(quint8)dircontrol_right);

     //   qDebug () << "AP " << message;

        return message;
    }

    QString send_othebutton(){

        QString message;

        message = QString::number((float)(quint8)waveoff_left) + ',' + QString::number((float)(quint8)waveoff_right) + ',' + QString::number((float)(quint8)off_at_left) + ','
                + QString::number((float)(quint8)off_at_right) + ',' + QString::number((float)yoke_stab_trim_left_1) + ',' + QString::number((float)off_vsup_left) + ','
                + QString::number((float)(quint8)yoke_stab_trim_right_1) + ',' + QString::number((float)(quint8)off_vsup_right);
        return message;

    }



};

struct BoxData{


    float ind_speed;                    // индикатор задатчика прборной скорости
    float ind_altitude;                 // индикатор задатчика высоты эшелона
    float ind_vertical_speed;           // индикатор задатчика вертикальной скорости
    float ind_angle;                    // индикатор задатчика ЗПУ

    char button_stab2;                  // кнопка включения-выключения режима «Стабилизация N2»
    char button_at;                     // кнопка подготовки ВСУТ к автоматическому управлению тягой двигателя
    char button_at_off;                 // кнопка выключения автоматического управления тягой двигателя
    char button_speed;                  // кнопка включения режима «Скорость»
    char button_echelon;                // кнопка включения режима «Выход на заданный эшелон»
    char button_stab_altitude;          // кнопка включения режима «Стабилизация высоты»
    char button_navig_vert;             // кнопка включения режима «Вертикальная навигация»
    char button_vertspeed;              // кнопка включения режима «Вертикальная скорость»
    char button_beam;                   // кнопка включения режима «Обратный луч»
    char button_land;                   // кнопка включения режима «Посадка»
    char button_zpu;                    // кнопка включения режима «ЗПУ»
    char button_zona;                   // кнопка включения режима «Курсовая зона»
    char button_navig_gor;              // кнопка включения режима «Горизонтальная навигация»
    char button_ON;                     // кнопка включения автоматического управления самолетом (режим «совмещенное управление»)
    char button_OFF;                    // кнопка выключения автоматического управления самолетом

    char button_mach;                   // режим отображения скорости (М или км/ч), переключаемый кнопкой V/M

    char button_onofflamps;             // вкл/откл индикаторов на панели ВСУП

    char onoff;                         // вкл/откл передачи


    // структура с данными для отправки в ВСУП
    BoxData() {
        ind_speed = 0.0;
        ind_altitude = 0.0;
        ind_vertical_speed = 0.0;
        ind_angle = 0.0;

        button_stab2 = 0x00;
        button_at = 0x00;
        button_at_off = 0x00;
        button_speed = 0x00;
        button_echelon = 0x00;
        button_stab_altitude = 0x00;
        button_navig_vert = 0x00;
        button_vertspeed = 0x00;
        button_beam = 0x00;
        button_land = 0x00;
        button_zpu = 0x00;
        button_zona = 0x00;
        button_navig_gor = 0x00;
        button_ON = 0x00;
        button_OFF = 0x00;

        button_mach = 0x00;

        button_onofflamps = 0xBB;
        onoff = 0xBB;
    }

    // функция перевода данных структуры в последоватльность байт для отправки в ВСУП
    QByteArray toByte(){

        QByteArray bytes;


        bytes.append(reinterpret_cast<const char*>(&ind_speed), sizeof(ind_speed));
        bytes.append(reinterpret_cast<const char*>(&ind_altitude), sizeof(ind_altitude));
        bytes.append(reinterpret_cast<const char*>(&ind_vertical_speed), sizeof(ind_vertical_speed));
        bytes.append(reinterpret_cast<const char*>(&ind_angle), sizeof(ind_angle));
        bytes.append(button_stab2);
        bytes.append(button_at);
        bytes.append(button_at_off);
        bytes.append(button_speed);
        bytes.append(button_echelon);
        bytes.append(button_stab_altitude);
        bytes.append(button_navig_vert);
        bytes.append(button_vertspeed);
        bytes.append(button_beam);
        bytes.append(button_land);
        bytes.append(button_zpu);
        bytes.append(button_zona);
        bytes.append(button_navig_gor);
        bytes.append(button_ON );
        bytes.append(button_OFF);
        bytes.append(button_onofflamps);
        bytes.append(onoff);

       // qDebug() << "скорость" <<ind_speed ;
       // qDebug() << "вертикальная скорость" << ind_speed ;
       // qDebug() << "ЭШЕЛОН" << ind_altitude ;
       // qDebug() << "ЗПУ"<< ind_angle;
        return bytes;
    }

};

}
