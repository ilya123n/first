#include <QCoreApplication>
#include <QDebug>
#include <QtCore>
#include <QObject>
#include <udpreceiver.h>
#include <QtNetwork>
#include <QVector>

using namespace css;

using namespace functions;

int main(int argc, char *argv[]) {
    QCoreApplication a(argc, argv);

    qDebug() << "VSUP Driver with ARD.";

    qint16 portproxy = 9701;
    UdpReceiver recev(portproxy);

    recev.start();

    //float result = mARDMAP(QString("1000"));
    //qDebug() << "R:" << result;

    return a.exec();
}

