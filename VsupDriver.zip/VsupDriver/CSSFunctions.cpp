/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   CSSFunctions.cpp
 * Author: V Shemetov
 * 
 * Created on June 2, 2017, 12:04 PM
 */

#include "CSSFunctions.h"
#include <QDebug>

namespace css{
namespace functions{

//

MultiTurnPotentiometer::MultiTurnPotentiometer() {

    init();
}

MultiTurnPotentiometer::MultiTurnPotentiometer(float r_thold) {

    init();
    this->reset_threshold_a0 = r_thold;
}

void MultiTurnPotentiometer::init() {

    current_semval = 0.00;
    dSemval        = 0.00;
}

float MultiTurnPotentiometer::countSemval(float current_angle) {

    float a1   = current_angle;
    float dDeg = a0 - a1;
    float local_dSemval = CSSFunctions::freqDeg2Semval(dDeg, resolution, semval_step);

    dSemval += local_dSemval;

    if ((dDeg > reset_threshold_a0) || (dDeg < -reset_threshold_a0))
        setA0(a1);

    if (dSemval > (range_rite - range_left)) {
        dSemval = (range_rite - range_left);
        setA0(a1);
    }

    if (dSemval < 0.00) {
        dSemval = 0.00;
        setA0(a1);
    }

    current_semval = range_left + dSemval;
    return current_semval;
}

void MultiTurnPotentiometer::setA0(float start_angle) {

    this->a0 = start_angle;
}

void MultiTurnPotentiometer::setCurrentSemval(float semval) {

    this->dSemval = semval - range_left;
}

void MultiTurnPotentiometer::setRange(float range_left, float range_rite) {

    this->range_left = range_left;
    this->range_rite = range_rite;
}

void MultiTurnPotentiometer::setCoeffs(float resolution, float semval_step) {

    this->resolution = resolution;
    this->semval_step = semval_step;
}

void MultiTurnPotentiometer::setThreshold(float r_thold) {

    this->reset_threshold_a0 = r_thold;
}

//

float CSSFunctions::mapI2F(int in_value, float in_min, float in_max, float out_min, float out_max) {
    
    float in_value_f = (float)in_value;
    
    if (in_value_f >= in_max)
        in_value_f = in_max;
    if (in_value_f <= in_min)
        in_value_f = in_min;
    
    return (in_value_f - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}

float CSSFunctions::mapF2F(float in_value, float in_min, float in_max, float out_min, float out_max) {

    if (in_value >= in_max)
        in_value = in_max;
    if (in_value <= in_min)
        in_value = in_min;

    return (in_value - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}

int CSSFunctions::byteArrayToInt(char b[]) {
    
    int value = 0;
    for (int i = 0; i < 4; i++) {
        int shift = (4 - 1 - i) * 8;
        value += (b[i] & 0x000000FF) << shift;
    }
    
    return value;
}

void CSSFunctions::binarySwitch(unsigned short &value) {
    
    value = (value == 0)? 1 : 0;
}

float CSSFunctions::kts2kmhs(float kts_value) {
    
    return kts_value * 1.852;
}

float CSSFunctions::ft2m(float ft_value) {
    
    return ft_value * 0.3048;
}

float CSSFunctions::m2ft(float m_value) {

    return m_value * 3.28084;
}

void CSSFunctions::incDecOnRange(unsigned short &value, int min, int max, bool &direction) {
    
    int gain = (direction)? 1 : -1;
    
    value += 1 * gain;
    
    direction = ((direction) &&!(value >= max)) | ((!direction) && (value <= min));
}

bool CSSFunctions::isOnRange(double value, double gauge, float accuracy) {

    return ((value >= gauge - accuracy) && (value <= gauge + accuracy));
}

}
}
