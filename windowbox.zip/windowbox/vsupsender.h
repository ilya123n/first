#pragma once

#include <QDebug>
#include "vsuptypes.h"
#include "udpsender.h"

namespace css {

using namespace vsup;

#define SENDING_INTERVAL_MS 500

class VsuSender : public QObject {
    Q_OBJECT

public:
    VsuSender();
    virtual ~VsuSender();

    Vsup* getdata();

private:
    Vsup* data_;
    UdpSender udp_sender;
    QTimer *timer;

    // Удаленный адрес
    QString remote_hostname;
    qint16  remote_port;

private slots:
    void sendData();
};

} // namespace css
