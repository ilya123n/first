#include "vsupsender.h"

namespace css {


VsuSender::VsuSender() {

    remote_hostname = "192.168.88.125";//"127.0.0.11";
    remote_port = 6565;

    data_ = new Vsup();

    timer = new QTimer();
    connect(timer, SIGNAL(timeout()), this, SLOT(sendData()));
    timer->start(SENDING_INTERVAL_MS);
}

VsuSender::~VsuSender() {

    delete data_;
}

Vsup* VsuSender::getdata() {

    return data_;
}

void VsuSender::sendData() {

    QHostAddress remote_hostadress(remote_hostname);
    udp_sender.send(data_->toByte(), remote_hostadress, remote_port);
}

}// namespace css


