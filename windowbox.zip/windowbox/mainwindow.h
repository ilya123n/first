#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <vsupsender.h>

namespace Ui {
class MainWindow;
}

using namespace css;

class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:
    void on_onland();

    void on_thrust();

    void on_offthrust();

    void on_stab2();

    void on_onspeed();

    void on_onechelon();

    void on_onaltitude();

    void on_onvertnav();

    void on_onvertspeed();

    void on_onbeam();

    void on_onzone();

    void on_ongornav();

    void on_onzpu();

    void on_oncombcontrol();

    void on_offvsup();

    void adjuster_speed_slider();

    void adjuster_altitude_slider();

    void adjuster_vertical_speed_slider();

    void adjuster_angle_slider();

    void offlamp_tablo();

    void on_extcontrol();

private:
    Ui::MainWindow *ui;

    // Контроллер-модель
    VsuSender vsu_sender;
};

#endif // MAINWINDOW_H
