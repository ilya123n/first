#pragma once

#include <QtCore>
#include <QtNetwork>

namespace css {

class UdpSender : public QObject {
    Q_OBJECT
public:
    UdpSender();

public slots:
    void send(QByteArray bytes, QHostAddress target, int port);

private:
    QUdpSocket socket;    
};

} // namespace css
