#include "udpsender.h"


namespace css {

UdpSender::UdpSender() {
}

void UdpSender::send(QByteArray bytes, QHostAddress target, int port) {

    socket.writeDatagram(bytes.data(), bytes.size(), target, port);
}

} // namespace css
