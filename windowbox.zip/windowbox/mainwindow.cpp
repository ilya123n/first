#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "vsupsender.h"
#include <QDebug>
#include <QSlider>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow) {

    ui->setupUi(this);
    connect(ui->thrust, SIGNAL(clicked()), this, SLOT(on_thrust()));
    connect(ui->offthrust, SIGNAL(clicked()), this, SLOT(on_offthrust()));
    connect(ui->stab2, SIGNAL(clicked()), this, SLOT(on_stab2()));
    connect(ui->onland, SIGNAL(clicked()), this, SLOT(on_onland()));
    connect(ui->onspeed, SIGNAL(clicked()), this, SLOT(on_onspeed()));
    connect(ui->onechelon, SIGNAL(clicked()), this, SLOT(on_onechelon()));
    connect(ui->onaltitude, SIGNAL(clicked()), this, SLOT(on_onaltitude()));
    connect(ui->onvertnav, SIGNAL(clicked()), this, SLOT(on_onvertnav()));
    connect(ui->onvertspeed, SIGNAL(clicked()), this, SLOT(on_onvertspeed()));
    connect(ui->onbeam, SIGNAL(clicked()), this, SLOT(on_onbeam()));
    connect(ui->onzone, SIGNAL(clicked()), this, SLOT(on_onzone()));
    connect(ui->ongornav, SIGNAL(clicked()), this, SLOT(on_ongornav()));
    connect(ui->onzpu, SIGNAL(clicked()), this, SLOT(on_onzpu()));
    connect(ui->oncombcontrol, SIGNAL(clicked()), this, SLOT(on_oncombcontrol()));
    connect(ui->offvsup, SIGNAL(clicked()), this, SLOT(on_offvsup()));
    connect(ui->onofflamps, SIGNAL(clicked()), this, SLOT(offlamp_tablo()));
    connect(ui->ext_control, SIGNAL(clicked()), this, SLOT(on_extcontrol()));

    connect(ui->adjuster_speed, SIGNAL(sliderReleased()), this, SLOT(adjuster_speed_slider()));
    connect(ui->adjuster_altitude, SIGNAL(sliderReleased()), this, SLOT(adjuster_altitude_slider()));
    connect(ui->adjuster_vertical_speed, SIGNAL(sliderReleased()), this, SLOT(adjuster_vertical_speed_slider()));
    connect(ui->adjuster_angle, SIGNAL(sliderReleased()), this, SLOT(adjuster_angle_slider()));
}

MainWindow::~MainWindow() {
    delete ui;

}        

void MainWindow::on_thrust() {
    if (vsu_sender.getdata()->button_thrust == 0x00) {
        vsu_sender.getdata()->button_thrust = 0xFF;
    }
    else {
        vsu_sender.getdata()->button_thrust = 0x00;
    }
}

void MainWindow::on_offthrust() {
    if (vsu_sender.getdata()->button_offtrust == 0x00) {
        vsu_sender.getdata()->button_offtrust = 0xFF;
    }
    else vsu_sender.getdata()->button_offtrust = 0x00;

}

void MainWindow::on_onland() {
    if (vsu_sender.getdata()->button_onland == 0x00) {
        vsu_sender.getdata()->button_onland = 0xFF;
    }
    else vsu_sender.getdata()->button_onland = 0x00;
}

void MainWindow::on_stab2() {
    if (vsu_sender.getdata()->button_stab2 == 0x00) {
        vsu_sender.getdata()->button_stab2 = 0xFF;
    }
    else vsu_sender.getdata()->button_stab2 = 0x00;
}


void MainWindow::on_onspeed() {
    if (vsu_sender.getdata()->button_onspeed == 0x00) {
        vsu_sender.getdata()->button_onspeed = 0xFF;
    }
    else vsu_sender.getdata()->button_onspeed = 0x00;
}

void MainWindow::on_onechelon() {
    if (vsu_sender.getdata()->button_onechelon == 0x00) {
        vsu_sender.getdata()->button_onechelon = 0xFF;
    }
    else vsu_sender.getdata()->button_onechelon = 0x00;
}

void MainWindow::on_onaltitude() {

    if (vsu_sender.getdata()->button_onaltitude == 0x00) {
        vsu_sender.getdata()->button_onaltitude = 0xFF;
    }
    else vsu_sender.getdata()->button_onaltitude = 0x00;
}

void MainWindow::on_onvertnav() {

    if (vsu_sender.getdata()->button_onvertnavig == 0x00) {
        vsu_sender.getdata()->button_onvertnavig = 0xFF;
    }
    else vsu_sender.getdata()->button_onvertnavig = 0x00;

}

void MainWindow::on_onvertspeed() {

    if (vsu_sender.getdata()->button_onvertspeed == 0x00) {
        vsu_sender.getdata()->button_onvertspeed = 0xFF;
    }
    else vsu_sender.getdata()->button_onvertspeed = 0x00;
}

void MainWindow::on_onbeam() {

    if (vsu_sender.getdata()->button_onbeam == 0x00) {
        vsu_sender.getdata()->button_onbeam = 0xFF;
    }
    else vsu_sender.getdata()->button_onbeam = 0x00;
}

void MainWindow::on_onzone() {

    if (vsu_sender.getdata()->button_onzone == 0x00) {
        vsu_sender.getdata()->button_onzone = 0xFF;
    }
    else vsu_sender.getdata()->button_onzone = 0x00;

}

void MainWindow::on_ongornav() {

    if (vsu_sender.getdata()->button_ongornav == 0x00) {
        vsu_sender.getdata()->button_ongornav = 0xFF;
    }
    else vsu_sender.getdata()->button_ongornav = 0x00;

}

void MainWindow::on_onzpu() {

    if (vsu_sender.getdata()->button_onzpu == 0x00) {
        vsu_sender.getdata()->button_onzpu = 0xFF;
    }
    else vsu_sender.getdata()->button_onzpu = 0x00;

}

void MainWindow::on_oncombcontrol() {

    if (vsu_sender.getdata()->button_oncombcontrol == 0x00) {
        vsu_sender.getdata()->button_oncombcontrol = 0xFF;
    }
    else vsu_sender.getdata()->button_oncombcontrol = 0x00;
}

void MainWindow::on_offvsup() {

    if (vsu_sender.getdata()->button_offvsup == 0x00) {
        vsu_sender.getdata()->button_offvsup = 0xFF;
    }
    else vsu_sender.getdata()->button_offvsup = 0x00;

}

void MainWindow::adjuster_speed_slider() {

    vsu_sender.getdata()->ind_speed = (float)ui->adjuster_speed->value();
    //qDebug() << vsu_sender.getdata()->ind_speed;

}

void MainWindow::adjuster_altitude_slider() {

    vsu_sender.getdata()->ind_altitude = (float)ui->adjuster_altitude->value();
    //qDebug() << vsu_sender.getdata()->ind_altitude;

}

void MainWindow::adjuster_vertical_speed_slider() {

    vsu_sender.getdata()->ind_vertical_speed = (float)ui->adjuster_vertical_speed->value();
}

void MainWindow::adjuster_angle_slider() {

    vsu_sender.getdata()->ind_angle = (float)ui->adjuster_angle->value();
}


/*
    if (vsu_sender.getdata()->button_onofflamps == 0xAA) {
        qDebug() << "!!!!!!!!!!!!!!!";
        vsu_sender.getdata()->button_onofflamps = 0xBB;
    }
    else vsu_sender.getdata()->button_onofflamps = 0xAA;




 if (vsu_sender.getdata()->button_thrust != 0xAA) {

        vsu_sender.getdata()->button_thrust = 0xAA;
        vsu_sender.getdata()->button_offtrust = 0xAA;
        vsu_sender.getdata()->button_onland = 0xAA;
        vsu_sender.getdata()->button_stab2 = 0xAA;
        vsu_sender.getdata()->button_onspeed = 0xAA;
        vsu_sender.getdata()->button_onechelon = 0xAA;
        vsu_sender.getdata()->button_onaltitude = 0xAA;
        vsu_sender.getdata()->button_onvertnavig = 0xAA;
        vsu_sender.getdata()->button_onvertspeed = 0xAA;
        vsu_sender.getdata()->button_onbeam = 0xAA;
        vsu_sender.getdata()->button_onzone = 0xAA;
        vsu_sender.getdata()->button_oncombcontrol = 0xAA;
        vsu_sender.getdata()->button_offvsup = 0xAA;
        vsu_sender.getdata()->button_onzpu = 0xAA;
        vsu_sender.getdata()->button_ongornav = 0xAA;

*/


void MainWindow::offlamp_tablo() {



    if (vsu_sender.getdata()->button_onofflamps == (char)0xAA) {
        vsu_sender.getdata()->button_onofflamps = 0xBB;
    } else vsu_sender.getdata()->button_onofflamps = 0xAA;

}

void MainWindow::on_extcontrol(){

    if(vsu_sender.getdata()->button_thrust != (char)0xAA) {
        vsu_sender.getdata()->button_thrust = 0xAA;
        vsu_sender.getdata()->button_offtrust = 0xAA;
        vsu_sender.getdata()->button_onland = 0xAA;
        vsu_sender.getdata()->button_stab2 = 0xAA;
        vsu_sender.getdata()->button_onspeed = 0xAA;
        vsu_sender.getdata()->button_onechelon = 0xAA;
        vsu_sender.getdata()->button_onaltitude = 0xAA;
        vsu_sender.getdata()->button_onvertnavig = 0xAA;
        vsu_sender.getdata()->button_onvertspeed = 0xAA;
        vsu_sender.getdata()->button_onbeam = 0xAA;
        vsu_sender.getdata()->button_onzone = 0xAA;
        vsu_sender.getdata()->button_oncombcontrol = 0xAA;
        vsu_sender.getdata()->button_offvsup = 0xAA;
        vsu_sender.getdata()->button_onzpu = 0xAA;
        vsu_sender.getdata()->button_ongornav = 0xAA;
    } else {

        vsu_sender.getdata()->button_thrust = 0x00;
        vsu_sender.getdata()->button_offtrust = 0x00;
        vsu_sender.getdata()->button_onland = 0x00;
        vsu_sender.getdata()->button_stab2 = 0x00;
        vsu_sender.getdata()->button_onspeed = 0x00;
        vsu_sender.getdata()->button_onechelon = 0x00;
        vsu_sender.getdata()->button_onaltitude = 0x00;
        vsu_sender.getdata()->button_onvertnavig = 0x00;
        vsu_sender.getdata()->button_onvertspeed = 0x00;
        vsu_sender.getdata()->button_onbeam = 0x00;
        vsu_sender.getdata()->button_onzone = 0x00;
        vsu_sender.getdata()->button_oncombcontrol = 0x00;
        vsu_sender.getdata()->button_offvsup = 0x00;
        vsu_sender.getdata()->button_onzpu = 0x00;
        vsu_sender.getdata()->button_ongornav = 0x00;

    }


}
