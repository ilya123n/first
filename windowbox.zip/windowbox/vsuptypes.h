#pragma once

#include <QtCore>

namespace css {
namespace vsup {



struct Vsup{

    float ind_speed;                    // индикатор задатчика прборной скорости
    float ind_altitude;                 // индикатор задатчика высоты эшелона
    float ind_vertical_speed;           // индикатор задатчика вертикальной скорости
    float ind_angle;                    // индикатор задатчика ЗПУ

    char button_stab2;                  // стабилизация 2
    char button_thrust;                 // подготовка к управлению тягой
    char button_offtrust;               // выключение управления тягой
    char button_onspeed;                // скорость
    char button_onechelon;              // выход на эшелон
    char button_onaltitude;             // стабилизация высоты
    char button_onvertnavig;            // вертикальная навигация
    char button_onvertspeed;            // вертикальная скорость
    char button_onbeam;                 // обратный луч
    char button_onland;                 // посадка
    char button_onzpu;                  // зпу
    char button_onzone;                 // курсовая зона
    char button_ongornav;               // горизонтальная навигация
    char button_oncombcontrol;          // совмещённое управление
    char button_offvsup;                // выкл авт упр

    char button_onofflamps;              // вкл/откл индикаторов на панели ВСУП

    char onoff;                         // вкл/откл передачи

    Vsup() {
        ind_speed = 0.0;
        ind_altitude = 176.182;
        ind_vertical_speed = 0.0;
        ind_angle = 0.0;

        button_stab2 = 0x00;
        button_thrust = 0x00;
        button_offtrust = 0x00;
        button_onspeed = 0x00;
        button_onechelon = 0x00;
        button_onaltitude = 0x00;
        button_onvertnavig = 0x00;
        button_onvertspeed = 0x00;
        button_onbeam = 0x00;
        button_onland = 0x00;
        button_onzpu = 0x00;
        button_onzone= 0x00;
        button_ongornav = 0x00;
        button_oncombcontrol = 0x00;
        button_offvsup = 0x00;
        button_onofflamps = 0xBB;
        onoff = 0xBB;
    }
    // функция перевода данных структуры в последоватльность байт для отправки
    QByteArray toByte(){
        QByteArray bytes;
        bytes.append(reinterpret_cast<const char*>(&ind_speed), sizeof(ind_speed));
        bytes.append(reinterpret_cast<const char*>(&ind_altitude), sizeof(ind_altitude));
        bytes.append(reinterpret_cast<const char*>(&ind_vertical_speed), sizeof(ind_vertical_speed));
        bytes.append(reinterpret_cast<const char*>(&ind_angle), sizeof(ind_angle));
        bytes.append(button_stab2);
        bytes.append(button_thrust);
        bytes.append(button_offtrust);
        bytes.append(button_onspeed);
        bytes.append(button_onechelon);
        bytes.append(button_onaltitude);
        bytes.append(button_onvertnavig);
        bytes.append(button_onvertspeed);
        bytes.append(button_onbeam);
        bytes.append(button_onland);
        bytes.append(button_onzpu);
        bytes.append(button_onzone);
        bytes.append(button_ongornav);
        bytes.append(button_oncombcontrol);
        bytes.append(button_offvsup);
        bytes.append(button_onofflamps);
        bytes.append(onoff);
        // Парсинг

    /*    float f1;
        float f2;
        float f3;
        float f4;

        QDataStream ds(&bytes, QIODevice::ReadOnly);

        ds.readRawData(reinterpret_cast<char*>(&f1), sizeof(f1));
        ds.readRawData(reinterpret_cast<char*>(&f2), sizeof(f2));
        ds.readRawData(reinterpret_cast<char*>(&f3), sizeof(f3));
        ds.readRawData(reinterpret_cast<char*>(&f4), sizeof(f4));

        qDebug() << "Floats:" << f1 << f2 << f3 << f4;
        qDebug() << "Stab2:" << bytes.mid(16,1); // bytes.at(16)
        qDebug() << "Thrust(bytes):" << bytes.mid(17,1);
        qDebug() << "Thrust:" << atof(bytes.mid(17,1));
        qDebug() << "Thrust:" << bytes.at(17);
*/
        qDebug() << bytes ;
        return bytes;
    }
};


} // namespace vsup
} // namespace css

