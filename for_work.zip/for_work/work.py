#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Mar  3 20:22:34 2018

@author: user
"""

#for work

import os
import hashlib
from functools import partial
import def_md5


# открытие файла с адресами каталогов файлов
f_config = open('config_md5.txt', 'r')
# создание пустого списка
list_address = []
# запись адресов папок в список
for line in f_config:
    list_address.append(line)
# рекурсивный поиск файлов в указанных диреркториях
for i in list_address:
    path = i[0:path.find('\n', 0, len(i))]
    for rootdir, dirs, files in os.walk(path):
        for file in files:
            print (os.path.join(rootdir, file))
            '''
            with open(os.path.join(rootdir, file), mode='rb') as f:
                d = hashlib.md5()
                for buf in iter(partial(f.read, 128), b''):
                    d.update(buf)
            print(d)
'''
            print(def_md5.hash_md5(os.path.join(rootdir, file)))



