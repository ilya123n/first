#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Mar  4 20:54:55 2018

@author: user
"""
import os
import hashlib

# функция расчёта md5
def hash_md5(filepath):
    m = hashlib.md5()
    fd = open(filepath, 'rb')
    b = fd.read()
    m.update(b)
    fd.close()
    return(m.hexdigest())