#pragma once

#include <QtCore>
#include <QtNetwork>

namespace css {

struct Target {
    QHostAddress host_address;
    int port;
};

class UdpSender : public QObject {
    Q_OBJECT
public:
    UdpSender();

public slots:
   // void sendmany(QByteArray bytes);
    void send(QByteArray bytes, QHostAddress target, int port);

private:
    QUdpSocket socket;
  //  QVector<Target> targets;
};

} // namespace css
