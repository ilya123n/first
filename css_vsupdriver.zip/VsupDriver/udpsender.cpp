#include "udpsender.h"


namespace css {

UdpSender::UdpSender() {
    //targets.append();
}

void UdpSender::send(QByteArray bytes, QHostAddress target, int port) {

    socket.writeDatagram(bytes.data(), bytes.size(), target, port);
}
/*
void sendmany(QByteArray bytes) {

    Target current_target;
    QVectorIterator<Target> it(targets);
    while(it.hasNext()) {
        current_target = it.next();
        send(bytes, current_target.host_address, current_target.port);
    }
}
*/
} // namespace css
