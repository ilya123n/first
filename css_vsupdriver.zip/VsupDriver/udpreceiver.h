#pragma once

#include <QtCore>
#include <QtNetwork>
#include <vsuptypes.h>
#include "udpsender.h"
#include <QVector>
#include <QSettings>


namespace css {

class UdpReceiver : public QObject {
    Q_OBJECT
public:
    UdpReceiver();
    UdpReceiver(qint16 thePort);
    virtual ~UdpReceiver();

    void start();
    void setBindPort(qint16 thePort);

    void parseVsup(QByteArray bytes);

    void parseXplane(QString qs);



 //   SimData getSimData();
    AllData getAllData();
    BoxData getBoxData();

  //  void setSimData(SimData &simData);
    void setAllData(AllData &allData);
    void setBoxData(BoxData &boxData);

private:
  //  SimData     tosim_;
    AllData     alldata_;
    BoxData     boxdata_;
    QUdpSocket  *socket;
    quint16     bindPort;
    UdpSender   udp_sender;
    //QString     remote_hostname;
    QString     xplane_hostname;
    QString     vsup_hostname;
    qint16      remote_port;
    QTimer      *timer;
    QVector<quint16> portVector;

    QSettings *settings;

    void init();

private slots:
    void read();
    void sendDataXplane();
    void sendVsup();


signals:
    void messageReceived(QByteArray);
  //  void toSimDataReceived(/*SimData &sim_data*/);
};


} // namespace css
