#include <QCoreApplication>
#include <QDebug>
#include <QtCore>
#include <QObject>
#include <udpreceiver.h>
#include <QtNetwork>
#include <QVector>

using namespace css;

int main(int argc, char *argv[]) {
    QCoreApplication a(argc, argv);

     qint16 portproxy = 9701;
     UdpReceiver recev(portproxy);

     recev.start();



    return a.exec();
}

