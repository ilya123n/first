#include "udpreceiver.h"
#include "vsuptypes.h"
#include <QVector>


namespace css {

#define Coefeditrimentspeed 65
#define Coefeditrimentaltitude 1000
#define Coefeditrimentvertspeed 10
#define Coefeditrimentangle 10

#define SENDING_INTERVAL_MS 500

UdpReceiver::UdpReceiver() {

    init();
}

UdpReceiver::UdpReceiver(qint16 thePort) {

    init();
    setBindPort(thePort);

}

void UdpReceiver::init() {

    socket = NULL;
    remote_port = 7878;
/*
    portVector.append(7800);    // порт для отправки данных об органах управления
    portVector.append(7801);    // порт для отправки данных от панели автопилота
    portVector.append(7802);    // порт для отправки данных о кнопках на блоке РУДов и штурвалах
    portVector.append(6600);
    portVector.append(7704);
*/
    timer = new QTimer();

    settings = new QSettings("/usr/local/share/css/vsupdriver/css_vsup_settings.conf",QSettings::NativeFormat);
    settings->beginGroup( "vsup" );
    portVector.append(settings->value("control_port", 0).toInt());                  // 0, порт для отправки данных об органах управлении
    portVector.append(settings->value("ap_port", 0).toInt());                       // 1, порт для отправки данных от панели автопилота
    portVector.append(settings->value("stickbuttons_port", 0).toInt());             // 2, порт для отправки данных о кнопках на блоке РУДов и штурвалах
    portVector.append(settings->value("vsup_port", 0).toInt());                     // 3, порт для отправки данных на ВСУП
    xplane_hostname = settings->value("xplane_hostname", 0).toString();             // адрес машины с x-plane
    vsup_hostname = settings->value("vsup_hostname", 0).toString();                 // адрес ВСУП
    settings->endGroup();

    qDebug() << portVector;
    qDebug() << vsup_hostname;
    qDebug() << xplane_hostname;

    connect(timer, SIGNAL(timeout()), this, SLOT(sendVsup()));
    connect(timer, SIGNAL(timeout()), this, SLOT(sendDataXplane()));
    timer->start(SENDING_INTERVAL_MS);

    //connect(this, SIGNAL(toSimDataReceived()), this, SLOT(sendDataXplane()));

}

UdpReceiver::~UdpReceiver() {

    if (socket)
      delete socket;

   // delete time;
}

void UdpReceiver::start() {

    qDebug() << "UdpReceiver::start at" << bindPort;

    if (!socket) {
        socket = new QUdpSocket(this);
        socket->bind(QHostAddress::Any, bindPort);

        connect(socket, SIGNAL(readyRead()), SLOT(read()));
    }
}

void UdpReceiver::setBindPort(qint16 thePort) {

    bindPort = thePort;
}

void UdpReceiver::read() {

  //  qDebug() << "read raw data";

    // Read editoming data

    QByteArray datagram;

    qint64 pending_size = socket->pendingDatagramSize();

    datagram.resize(socket->pendingDatagramSize());

    QHostAddress *address = new QHostAddress();
    socket->readDatagram(datagram.data(), datagram.size(), address);

    std::string st = datagram.toStdString();                            // преобразование QByteArray datagram в строку StdString st
    QString qs = QString::fromLocal8Bit(st.c_str());                    // преобразование строки st StdString в qs Qstring

    if (pending_size == 94 ){

        emit messageReceived(datagram);

    //    qDebug() << "from VSUP:_" << datagram;

        parseVsup(datagram);                                             // вызов парсера для пакета от ВСУП

    } else if(qs.indexOf(",") != -1) {

        qDebug() << "from X-=lane:_" << qs;

        parseXplane(qs);
    }

    delete address;
}
/*
SimData UdpReceiver::getSimData() {

    return tosim_;
}
*/
AllData UdpReceiver::getAllData() {

    return alldata_;
}

BoxData UdpReceiver::getBoxData(){

    return boxdata_;
}

/*void UdpReceiver::setSimData(SimData &simData) {

    tosim_ = simData;
}
*/

void UdpReceiver::setAllData(AllData &allData) {

    alldata_ = allData;
}

void UdpReceiver::setBoxData(BoxData &boxData) {

    boxdata_ = boxData;
}

void UdpReceiver::parseVsup(QByteArray bytes) {

    float yoke_roll;                    // отклонене штурвала по крену
    float yoke_pitch;                   // отклонене штурвала по тангажу

    float pedal_left;                   // отклонение педалей левого пилота
    float pedal_left_left;              // нажатие левой педали левого пилота
    float pedal_left_right;             // нажатие правой педали левого пилота

    float pedal_right;                  // отклонения педалей правого пилота
    float pedal_right_left;             // нажатие левой педали правого пилота
    float pedal_right_right;            // нажатие правой педали правого пилота

    float CST_1;                        // отклонение РУД_1
    float CST_2;                        // отклонение РУД_2
    float CST_3;                        // отклонение РУД_3
    float CST_4;                        // отклонение РУД_4

    float edit_speed;                   // приращение значения на индикаторе задатчика скорости
    float edit_altitude;                // приращение значения на индикаторе задатчика эшелона
    float edit_vertspeed;               // приращение значения на индикаторе задатчика вертикальной скорости
    float edit_angle;                   // приращение значения на индикаторе задатчика путевого угла

    QDataStream sb(&bytes, QIODevice::ReadOnly);

    sb.readRawData(reinterpret_cast<char*>(&yoke_roll), sizeof(yoke_roll));
    sb.readRawData(reinterpret_cast<char*>(&yoke_pitch), sizeof(yoke_pitch));

    sb.readRawData(reinterpret_cast<char*>(&pedal_left), sizeof(pedal_left));
    sb.readRawData(reinterpret_cast<char*>(&pedal_left_left), sizeof(pedal_left_left));
    sb.readRawData(reinterpret_cast<char*>(&pedal_left_right), sizeof(pedal_left_right));

    sb.readRawData(reinterpret_cast<char*>(&pedal_right), sizeof(pedal_right));
    sb.readRawData(reinterpret_cast<char*>(&pedal_right_left), sizeof(pedal_right_left));
    sb.readRawData(reinterpret_cast<char*>(&pedal_right_right), sizeof(pedal_right_right));

    sb.readRawData(reinterpret_cast<char*>(&CST_1), sizeof(CST_1));
    sb.readRawData(reinterpret_cast<char*>(&CST_2), sizeof(CST_2));
    sb.readRawData(reinterpret_cast<char*>(&CST_3), sizeof(CST_3));
    sb.readRawData(reinterpret_cast<char*>(&CST_4), sizeof(CST_4));

    sb.readRawData(reinterpret_cast<char*>(&edit_speed), sizeof(edit_speed));
    sb.readRawData(reinterpret_cast<char*>(&edit_altitude), sizeof(edit_altitude));
    sb.readRawData(reinterpret_cast<char*>(&edit_vertspeed), sizeof(edit_vertspeed));
    sb.readRawData(reinterpret_cast<char*>(&edit_angle), sizeof(edit_angle));

   // qDebug() << "YOKE AND PEDAL: " + QString::number(yoke_roll) + "_" + QString::number(yoke_pitch) + "_" + QString::number(pedal_left) + "_" + QString::number(pedal_right);
   qDebug() << "ПРИРАЩЕНИЯ: " + QString::number(edit_speed) + "___________" + QString::number(edit_altitude) + "____________" + QString::number(edit_vertspeed) + "____________" + QString::number(edit_angle);
   // qDebug() << "CST: " + QString::number(CST_1) + "_" + QString::number(CST_2) + "_" + QString::number(CST_3) + "_" + QString::number(CST_4);
  //  qDebug() << "YOKE AND PEDAL: " + QString::number(yoke_roll) + "_" + QString::number(yoke_pitch) + "_" + QString::number(pedal_left) + "_" + QString::number(pedal_left_left) +
    //            "_" + QString::number(pedal_left_right) + "_" + QString::number(pedal_right) +  + "_" + QString::number(pedal_right_left) + "_" + QString::number(pedal_right_right);


   // qDebug() << "ПРИРАЩЕНИЕ ЭШЕЛОН:" << QString::number(edit_altitude) ;

   // qDebug() << "ПРИРАЩЕНИЕ ЗПУ:" << QString::number(edit_angle);


    // запись данных в поля структуры AllData

    alldata_.control_flat = bytes.at(64);
    alldata_.control_spoiler = bytes.at(65);
    alldata_.dircontrol_left = bytes.at(66);
    alldata_.button_stab2 = bytes.at(67);
    alldata_.button_at = bytes.at(68);
    alldata_.button_at_off = bytes.at(69);
    alldata_.button_speed = bytes.at(70);
    alldata_.button_echelon = bytes.at(71);
    alldata_.button_stab_altitude = bytes.at(72);
    alldata_.button_navig_vert = bytes.at(73);
    alldata_.button_beam = bytes.at(74);
    alldata_.button_vertspeed = bytes.at(75);
    alldata_.button_land = bytes.at(76);
    alldata_.button_zpu = bytes.at(77);
    alldata_.button_zona = bytes.at(78);
    alldata_.button_navig_gor = bytes.at(79);
    alldata_.button_ON = bytes.at(80);
    alldata_.button_OFF = bytes.at(81);
    alldata_.dircontrol_right = bytes.at(82);
    alldata_.button_mach = bytes.at(83);

    alldata_.yoke_roll = yoke_roll;
    alldata_.yoke_pitch = yoke_pitch;

    alldata_.pedal_left = pedal_left;
    alldata_.pedal_left_left = pedal_left_left;
    alldata_.pedal_left_right = pedal_left_right;
    alldata_.pedal_right = pedal_right;
    alldata_.pedal_right_left = pedal_right_left;
    alldata_.pedal_right_right = pedal_right_right;

    alldata_.CST_1 = CST_1;
    alldata_.CST_2 = CST_2;
    alldata_.CST_3 = CST_3;
    alldata_.CST_4 = CST_4;

    alldata_.limit(edit_speed, edit_altitude, edit_vertspeed, edit_vertspeed, Coefeditrimentspeed, Coefeditrimentaltitude, Coefeditrimentvertspeed, Coefeditrimentangle);

    //записаь данных в поля структуры SimData
    /*
    tosim_.yoke_roll = alldata_.yoke_roll;
    tosim_.yoke_pitch = alldata_.yoke_pitch;
    tosim_.pedal = alldata_.pedal_left;
    tosim_.break_left = alldata_.pedal_left_left;
    tosim_.break_right = alldata_.pedal_right_right;
    tosim_.CST_1 = alldata_.CST_1;
    tosim_.CST_2 = alldata_.CST_2;
    tosim_.CST_3 = alldata_.CST_3;
    tosim_.CST_4 = alldata_.CST_4;

    tosim_.AP_stab_altitude = (float)alldata_.button_stab_altitude;
    tosim_.AP_gor_nav = (float)alldata_.button_navig_gor;
    tosim_.AP_ON = (float)alldata_.button_ON;
    tosim_.AP_OFF = (float)alldata_.button_OFF;
*/
    // запись данных в поля структуры BoxData


    boxdata_.ind_speed = alldata_.ind_speed;

    boxdata_.ind_altitude = alldata_.ind_altitude;

    boxdata_.ind_vertical_speed = alldata_.ind_vertical_speed;

    boxdata_.ind_angle = alldata_.ind_angle;


    //emit toSimDataReceived();
}

void UdpReceiver::parseXplane(QString qs) {

    QStringList list = qs.split(',');

    boxdata_.button_stab2 =         (char)list.at(0).toInt();
    boxdata_.button_at =            (char)list.at(1).toInt();
   // boxdata_.button_at_off =        (char)list.at(2).toInt();
    boxdata_.button_speed =         (char)list.at(2).toInt();
    boxdata_.button_echelon =       (char)list.at(3).toInt();
    boxdata_.button_stab_altitude = (char)list.at(4).toInt();
    boxdata_.button_navig_vert =    (char)list.at(5).toInt();
    boxdata_.button_vertspeed =     (char)list.at(6).toInt();
    boxdata_.button_land =          (char)list.at(7).toInt();
    boxdata_.button_zpu =           (char)list.at(8).toInt();
    boxdata_.button_zona =          (char)list.at(9).toInt();
    boxdata_.button_navig_gor =     (char)list.at(10).toInt();
    boxdata_.button_ON =            (char)list.at(11).toInt();
  //  boxdata_.button_OFF =           (char)list.at(13).toInt();

}

void UdpReceiver::sendDataXplane() {

    QHostAddress remote_hostadress(xplane_hostname);
    udp_sender.send(alldata_.send_control().toLocal8Bit(), remote_hostadress, portVector.at(0));
    udp_sender.send(alldata_.send_ap().toLocal8Bit(), remote_hostadress, portVector.at(1));
    udp_sender.send(alldata_.send_othebutton().toLocal8Bit(), remote_hostadress, portVector.at(2));
    //udp_sender.send(boxdata_.toByte(),remote_hostadress, remote_port);


}

void UdpReceiver::sendVsup() {

    QHostAddress remote_hostadress(vsup_hostname);
    udp_sender.send(boxdata_.toByte(), remote_hostadress, portVector.at(3));

}



} // namespace css
